java -jar Mayacron.jar $1
